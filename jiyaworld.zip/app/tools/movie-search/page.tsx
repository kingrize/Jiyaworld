"use client";

import { useState, FormEvent } from "react";
import styles from "./movie-search.module.css";

interface MovieResult {
    slug: string;
    title: string;
    thumbnail: string;
    rating: number | null;
    type: "movie" | "series";
}

interface SearchResponse {
    success: boolean;
    results: MovieResult[];
    error?: string;
}

export default function MovieSearchPage() {
    const [query, setQuery] = useState("");
    const [results, setResults] = useState<MovieResult[]>([]);
    const [loading, setLoading] = useState(false);
    const [hasSearched, setHasSearched] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSearch = async (e: FormEvent) => {
        e.preventDefault();
        if (!query.trim()) return;

        setLoading(true);
        setError(null);
        setHasSearched(true);
        setResults([]);

        try {
            const res = await fetch(`/api/external-search?q=${encodeURIComponent(query)}`);
            const data: SearchResponse = await res.json();

            if (data.success) {
                setResults(data.results);
            } else {
                setError(data.error || "Failed to fetch results");
            }
        } catch (err) {
            setError("An unexpected error occurred. Please try again.");
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className={styles.container}>
            <header className={styles.header}>
                <h1 className={styles.title}>Movie & Series Search</h1>
                <p className={styles.subtitle}>
                    Discover movies and TV series instantly. Powered by our external search integration.
                </p>

                <form onSubmit={handleSearch} className={styles.searchForm}>
                    <input
                        type="text"
                        className={styles.searchInput}
                        placeholder="Search for movies, series..."
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        autoFocus
                    />
                    <button type="submit" className={styles.searchButton} disabled={loading}>
                        {loading ? "Searching..." : "Search"}
                    </button>
                </form>
            </header>

            <main>
                {loading && (
                    <div className={styles.loader}>
                        <div className={styles.spinner} />
                    </div>
                )}

                {error && (
                    <div className={styles.emptyState}>
                        <p style={{ color: "var(--error)" }}>{error}</p>
                    </div>
                )}

                {!loading && hasSearched && results.length === 0 && !error && (
                    <div className={styles.emptyState}>
                        <h3>No results found</h3>
                        <p>Try adjusting your search terms.</p>
                    </div>
                )}

                <div className={styles.grid}>
                    {results.map((item) => (
                        <div key={item.slug} className={styles.card}>
                            <div className={styles.imageWrapper}>
                                {item.thumbnail ? (
                                    /* eslint-disable-next-line @next/next/no-img-element */
                                    <img
                                        src={item.thumbnail}
                                        alt={item.title}
                                        className={styles.thumbnail}
                                        loading="lazy"
                                        onError={(e) => {
                                            (e.target as HTMLImageElement).src =
                                                "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100%25' height='100%25' viewBox='0 0 800 1200' style='background:%232d2d2d;fill:%23555'%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-family='sans-serif' font-size='48'%3ENo Image%3C/text%3E%3C/svg%3E";
                                        }}
                                    />
                                ) : (
                                    <div
                                        style={{
                                            width: "100%",
                                            height: "100%",
                                            background: "var(--surface-container-highest)",
                                            display: "flex",
                                            alignItems: "center",
                                            justifyContent: "center",
                                            color: "var(--on-surface-variant)",
                                        }}
                                    >
                                        No Image
                                    </div>
                                )}
                            </div>
                            <div className={styles.cardContent}>
                                <h3 className={styles.cardTitle} title={item.title}>
                                    {item.title}
                                </h3>
                                <div className={styles.cardMeta}>
                                    <span className={styles.typeBadge}>{item.type}</span>
                                    {item.rating !== null && (
                                        <div className={styles.rating}>
                                            <span className={styles.ratingIcon}>★</span>
                                            {item.rating.toFixed(1)}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </main>
        </div>
    );
}
