import { NextRequest, NextResponse } from "next/server";

interface StreamResponse {
    success?: boolean;
    data?: {
        video_url?: string;
        subtitle_url?: string;
    };
}

export async function GET(request: NextRequest) {
    const searchParams = request.nextUrl.searchParams;
    const slug = searchParams.get("slug");
    const episode = searchParams.get("episode");

    if (!slug) {
        return NextResponse.json(
            { success: false, error: "Missing slug parameter" },
            { status: 400 }
        );
    }

    const externalUrl = new URL("https://zeldvorik.ru/rebahin21/api.php");
    externalUrl.searchParams.set("action", "stream");
    externalUrl.searchParams.set("slug", slug);

    if (episode) {
        externalUrl.searchParams.set("episode", episode);
    }

    try {
        const res = await fetch(externalUrl.toString(), {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "application/json",
            },
            cache: "no-store",
        });

        if (!res.ok) {
            throw new Error(`External API responded with ${res.status}`);
        }

        const data: StreamResponse = await res.json();

        if (!data.success || !data.data?.video_url) {
            return NextResponse.json(
                { success: false, error: "Stream not available" },
                { status: 404 }
            );
        }

        return NextResponse.json({
            success: true,
            video_url: data.data.video_url,
            subtitle_url: data.data.subtitle_url || null,
            timestamp: Date.now(),
        });
    } catch (error) {
        console.error("Stream resolution error:", error);
        return NextResponse.json(
            { success: false, error: "Failed to resolve stream" },
            { status: 500 }
        );
    }
}
