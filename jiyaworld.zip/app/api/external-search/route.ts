import { NextRequest, NextResponse } from "next/server";

interface ExternalItem {
    slug?: string;
    title?: string;
    thumbnail?: string;
    rating?: string;
    year?: string;
    type?: string;
}

interface ExternalResponse {
    success?: boolean;
    query?: string;
    page?: number | string;
    data?: ExternalItem[];
    total?: number | string;
}

export async function GET(request: NextRequest) {
    const searchParams = request.nextUrl.searchParams;
    const q = searchParams.get("q");
    const page = searchParams.get("page") || "1";

    if (!q) {
        return NextResponse.json(
            { success: false, error: "Missing query parameter 'q'" },
            { status: 400 }
        );
    }

    const externalUrl = new URL("https://zeldvorik.ru/rebahin21/api.php");
    externalUrl.searchParams.set("action", "search");
    externalUrl.searchParams.set("q", q);
    externalUrl.searchParams.set("page", page);

    try {
        const res = await fetch(externalUrl.toString(), {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                "Accept": "application/json"
            },
        });

        if (!res.ok) {
            throw new Error(`External API responded with ${res.status}`);
        }

        const data: ExternalResponse = await res.json();

        const normalizedResults = (data.data || []).map((item) => {
            // Normalize rating
            let rating: number | null = null;
            if (item.rating && typeof item.rating === "string") {
                const parsed = parseFloat(item.rating);
                if (!isNaN(parsed)) {
                    rating = parsed;
                }
            }

            // Normalize type
            let type: "movie" | "series" = "movie"; // Default fallback
            if (item.type?.toLowerCase() === "series") {
                type = "series";
            }

            return {
                slug: item.slug || "",
                title: item.title || "Untitled",
                thumbnail: item.thumbnail || "",
                rating: rating,
                type: type,
            };
        });

        const total = typeof data.total === "string" ? parseInt(data.total) || 0 : data.total || 0;
        const pageNum = typeof data.page === "string" ? parseInt(data.page) || 1 : data.page || 1;

        return NextResponse.json({
            success: true,
            query: q,
            page: pageNum,
            total: total,
            results: normalizedResults,
        });

    } catch (error) {
        console.error("External API Error:", error);
        return NextResponse.json(
            { success: false, error: "Failed to fetch data", results: [] },
            { status: 500 }
        );
    }
}
