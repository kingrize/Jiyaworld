import { NextRequest } from "next/server";

export const runtime = "edge";

export async function GET(request: NextRequest) {
    const url = request.nextUrl.searchParams.get("url");

    if (!url) {
        return new Response("Missing url parameter", { status: 400 });
    }

    try {
        const decodedUrl = decodeURIComponent(url);

        const rangeHeader = request.headers.get("range");

        const headers: HeadersInit = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "*/*",
            "Accept-Encoding": "identity",
            "Referer": new URL(decodedUrl).origin + "/",
        };

        if (rangeHeader) {
            headers["Range"] = rangeHeader;
        }

        const response = await fetch(decodedUrl, {
            headers,
            redirect: "follow",
        });

        if (!response.ok && response.status !== 206) {
            return new Response("Stream unavailable", { status: response.status });
        }

        const responseHeaders = new Headers();

        const contentType = response.headers.get("content-type");
        if (contentType) {
            responseHeaders.set("Content-Type", contentType);
        } else {
            responseHeaders.set("Content-Type", "video/mp4");
        }

        const contentLength = response.headers.get("content-length");
        if (contentLength) {
            responseHeaders.set("Content-Length", contentLength);
        }

        const contentRange = response.headers.get("content-range");
        if (contentRange) {
            responseHeaders.set("Content-Range", contentRange);
        }

        const acceptRanges = response.headers.get("accept-ranges");
        if (acceptRanges) {
            responseHeaders.set("Accept-Ranges", acceptRanges);
        } else {
            responseHeaders.set("Accept-Ranges", "bytes");
        }

        responseHeaders.set("Access-Control-Allow-Origin", "*");
        responseHeaders.set("Cache-Control", "public, max-age=3600");

        return new Response(response.body, {
            status: response.status,
            headers: responseHeaders,
        });
    } catch (error) {
        console.error("Stream proxy error:", error);
        return new Response("Stream error", { status: 500 });
    }
}
