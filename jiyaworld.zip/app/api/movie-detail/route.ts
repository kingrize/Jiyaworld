import { NextRequest, NextResponse } from "next/server";

interface Episode {
    number: number;
    title?: string;
    player_url?: string;
    video_url?: string;
    subtitle_url?: string;
}

interface ExternalDetailResponse {
    success?: boolean;
    data?: {
        slug?: string;
        title?: string;
        thumbnail?: string;
        rating?: string;
        year?: string;
        type?: string;
        genres?: string[];
        synopsis?: string;
        player_url?: string;
        video_url?: string;
        subtitle_url?: string;
        episodes?: Episode[];
    };
}

export async function GET(request: NextRequest) {
    const searchParams = request.nextUrl.searchParams;
    const slug = searchParams.get("slug");

    if (!slug) {
        return NextResponse.json(
            { success: false, error: "Missing slug parameter" },
            { status: 400 }
        );
    }

    const externalUrl = new URL("https://zeldvorik.ru/rebahin21/api.php");
    externalUrl.searchParams.set("action", "detail");
    externalUrl.searchParams.set("slug", slug);

    try {
        const res = await fetch(externalUrl.toString(), {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "application/json",
            },
        });

        if (!res.ok) {
            throw new Error(`External API responded with ${res.status}`);
        }

        const data: ExternalDetailResponse = await res.json();

        if (!data.success || !data.data) {
            return NextResponse.json(
                { success: false, error: "Movie not found" },
                { status: 404 }
            );
        }

        const movie = data.data;

        const normalizedEpisodes = (movie.episodes || []).map((ep) => ({
            number: ep.number,
            title: ep.title || `Episode ${ep.number}`,
            player_url: ep.player_url || null,
            video_url: ep.video_url || null,
            subtitle_url: ep.subtitle_url || null,
        }));

        let rating: number | null = null;
        if (movie.rating) {
            const parsed = parseFloat(movie.rating);
            if (!isNaN(parsed)) rating = parsed;
        }

        return NextResponse.json({
            success: true,
            data: {
                slug: movie.slug || slug,
                title: movie.title || "Untitled",
                thumbnail: movie.thumbnail || "",
                rating: rating,
                year: movie.year || "",
                type: movie.type?.toLowerCase() === "series" ? "series" : "movie",
                genres: movie.genres || [],
                synopsis: movie.synopsis || "",
                player_url: movie.player_url || null,
                video_url: movie.video_url || null,
                subtitle_url: movie.subtitle_url || null,
                episodes: normalizedEpisodes,
            },
        });
    } catch (error) {
        console.error("External Detail API Error:", error);
        return NextResponse.json(
            { success: false, error: "Failed to fetch movie details" },
            { status: 500 }
        );
    }
}
