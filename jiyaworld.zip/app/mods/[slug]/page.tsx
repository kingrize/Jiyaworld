/* app/mods/[slug]/page.tsx */
"use client";

import { use, useState } from "react";
import Link from "next/link";
import {
    FileCode2,
    Package,
    Download,
    Clock,
    Tag,
    AlertTriangle,
    CheckCircle2,
    FlaskConical,
    ArrowLeft,
    Copy,
    Check,
    AlertCircle,
    History,
    ChevronDown,
    ChevronUp,
    BookOpen,
    Info,
    Sparkles,
    Shield,
    Wrench,
    ExternalLink,
} from "lucide-react";
import { useMod } from "@/hooks/useMods";
import {
    ModPost,
    ModVersion,
    ModFeature,
    ModType,
    ModStatus,
    getLatestVersion,
    formatDate
} from "@/lib/mods/types";

// ============================================
// COMPONENTS
// ============================================

// Status badge with semantic colors
const StatusBadge = ({ status, size = "sm" }: { status: ModStatus; size?: "sm" | "md" }) => {
    const config = {
        stable: {
            icon: CheckCircle2,
            label: "Stable",
            className: "detail-badge detail-badge--stable",
        },
        beta: {
            icon: FlaskConical,
            label: "Beta",
            className: "detail-badge detail-badge--beta"
        },
        experimental: {
            icon: AlertTriangle,
            label: "Experimental",
            className: "detail-badge detail-badge--experimental",
        },
    };

    const { icon: Icon, label, className } = config[status];

    return (
        <span className={`${className} ${size === "md" ? "detail-badge--md" : ""}`}>
            <Icon size={size === "md" ? 14 : 12} />
            <span>{label}</span>
        </span>
    );
};

// Type badge with category colors
const TypeBadge = ({ type, size = "sm" }: { type: ModType; size?: "sm" | "md" }) => {
    const config = {
        script: {
            icon: FileCode2,
            label: "Script",
            className: "detail-type detail-type--script"
        },
        mod: {
            icon: Package,
            label: "Mod APK",
            className: "detail-type detail-type--mod"
        },
    };

    const { icon: Icon, label, className } = config[type];

    return (
        <span className={`${className} ${size === "md" ? "detail-type--md" : ""}`}>
            <Icon size={size === "md" ? 14 : 12} />
            <span>{label}</span>
        </span>
    );
};

// Section header with icon
const SectionHeader = ({
    icon: Icon,
    title,
    variant = "default"
}: {
    icon: React.ElementType;
    title: string;
    variant?: "default" | "warning";
}) => (
    <div className={`detail-section-header ${variant === "warning" ? "detail-section-header--warning" : ""}`}>
        <div className="detail-section-icon">
            <Icon size={16} />
        </div>
        <h2 className="detail-section-title">{title}</h2>
    </div>
);

// Feature item with inline risk indicator
const FeatureItem = ({ feature }: { feature: ModFeature }) => {
    const isRisky = feature.risk && feature.risk !== "none";

    return (
        <li className={`detail-feature ${isRisky ? "detail-feature--risky" : ""}`}>
            <span className="detail-feature-bullet">
                {isRisky ? (
                    <AlertTriangle size={14} />
                ) : (
                    <CheckCircle2 size={14} />
                )}
            </span>
            <span className="detail-feature-text">
                {feature.text}
                {isRisky && feature.riskNote && (
                    <span className="detail-feature-risk"> — {feature.riskNote}</span>
                )}
            </span>
        </li>
    );
};

// Features list with expand/collapse
const FeatureList = ({ features }: { features: ModFeature[] }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    const PREVIEW_COUNT = 5;

    const shouldCollapse = features.length > PREVIEW_COUNT;
    const visibleFeatures = isExpanded || !shouldCollapse
        ? features
        : features.slice(0, PREVIEW_COUNT);

    return (
        <div className="detail-features">
            <ul className="detail-feature-list">
                {visibleFeatures.map((feature, idx) => (
                    <FeatureItem key={idx} feature={feature} />
                ))}
            </ul>

            {shouldCollapse && (
                <button
                    type="button"
                    className="detail-expand-btn"
                    onClick={() => setIsExpanded(!isExpanded)}
                >
                    <span>{isExpanded ? "Show less" : `Show all ${features.length} features`}</span>
                    {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                </button>
            )}
        </div>
    );
};

// Version history accordion
const VersionHistory = ({ versions }: { versions: ModVersion[] }) => {
    const [isExpanded, setIsExpanded] = useState(false);

    const olderVersions = versions.filter(v => !v.isLatest);
    if (olderVersions.length === 0) return null;

    return (
        <div className="detail-version-history">
            <button
                type="button"
                className="detail-version-toggle"
                onClick={() => setIsExpanded(!isExpanded)}
            >
                <History size={14} />
                <span>
                    {olderVersions.length} previous {olderVersions.length === 1 ? "release" : "releases"}
                </span>
                {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>

            {isExpanded && (
                <div className="detail-version-list">
                    {olderVersions.map((version, idx) => (
                        <div key={idx} className="detail-version-item">
                            <div className="detail-version-row">
                                <code className="detail-version-tag">v{version.version}</code>
                                <StatusBadge status={version.status} />
                                <span className="detail-version-meta">{formatDate(version.createdAt)}</span>
                                <span className="detail-version-meta">{version.fileSize}</span>
                            </div>
                            {version.changelog && version.changelog.length > 0 && (
                                <ul className="detail-version-changelog">
                                    {version.changelog.map((entry, i) => (
                                        <li key={i}>{entry}</li>
                                    ))}
                                </ul>
                            )}
                            <Link href={`/d/${version.downloadSlug}`} className="detail-version-dl">
                                <Download size={12} />
                                <span>Download</span>
                            </Link>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

// ============================================
// DETAIL VIEW
// ============================================

function ModDetailView({ mod }: { mod: ModPost }) {
    const [copied, setCopied] = useState(false);
    const latestVersion = getLatestVersion(mod);

    const handleCopyLink = () => {
        navigator.clipboard.writeText(window.location.href);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <article className="detail-content">
            {/* Back navigation */}
            <Link href="/mods" className="detail-back">
                <ArrowLeft size={16} />
                <span>Back to repository</span>
            </Link>

            {/* ================================
                1. HEADER SECTION
            ================================ */}
            <header className="detail-header">
                <div className="detail-header-top">
                    <TypeBadge type={mod.type} size="md" />
                    <StatusBadge status={mod.status} size="md" />
                </div>
                <h1 className="detail-title">{mod.name}</h1>
                <div className="detail-meta">
                    <span className="detail-meta-item">
                        <Tag size={14} />
                        <span>{mod.game}</span>
                    </span>
                    <span className="detail-meta-divider">•</span>
                    <span className="detail-meta-item">
                        <Clock size={14} />
                        <span>Updated {formatDate(mod.updatedAt)}</span>
                    </span>
                </div>
            </header>

            {/* ================================
                2. DESCRIPTION / README
            ================================ */}
            <section className="detail-section">
                <SectionHeader icon={BookOpen} title="Description" />
                <div className="detail-readme">
                    <p>{mod.description}</p>
                </div>
            </section>

            {/* ================================
                3. VERSION & COMPATIBILITY
            ================================ */}
            {latestVersion && (
                <section className="detail-section">
                    <SectionHeader icon={Info} title="Version Info" />
                    <div className="detail-info-table">
                        <div className="detail-info-row">
                            <span className="detail-info-label">Version</span>
                            <code className="detail-info-value">v{latestVersion.version}</code>
                        </div>
                        <div className="detail-info-row">
                            <span className="detail-info-label">File Size</span>
                            <code className="detail-info-value">{latestVersion.fileSize}</code>
                        </div>
                        <div className="detail-info-row">
                            <span className="detail-info-label">Status</span>
                            <code className="detail-info-value">{latestVersion.status}</code>
                        </div>
                        <div className="detail-info-row">
                            <span className="detail-info-label">Released</span>
                            <code className="detail-info-value">{formatDate(latestVersion.createdAt)}</code>
                        </div>
                    </div>
                </section>
            )}

            {/* ================================
                4. FEATURES
            ================================ */}
            {mod.features && mod.features.length > 0 && (
                <section className="detail-section">
                    <SectionHeader icon={Sparkles} title="Features" />
                    <FeatureList features={mod.features} />
                </section>
            )}

            {/* ================================
                5. REQUIREMENTS
            ================================ */}
            {mod.requirements && mod.requirements.length > 0 && (
                <section className="detail-section">
                    <SectionHeader icon={Shield} title="Requirements" />
                    <ul className="detail-requirements">
                        {mod.requirements.map((req, idx) => (
                            <li key={idx} className="detail-requirement">
                                <span className="detail-requirement-bullet">•</span>
                                <span>{req}</span>
                            </li>
                        ))}
                    </ul>
                </section>
            )}

            {/* ================================
                6. INSTALLATION
            ================================ */}
            {mod.installationSteps && mod.installationSteps.length > 0 && (
                <section className="detail-section">
                    <SectionHeader icon={Wrench} title="Installation" />
                    <ol className="detail-steps">
                        {mod.installationSteps.map((step, idx) => (
                            <li key={idx} className="detail-step">
                                <span className="detail-step-num">{idx + 1}</span>
                                <span className="detail-step-text">{step}</span>
                            </li>
                        ))}
                    </ol>
                </section>
            )}

            {/* ================================
                7. WARNINGS
            ================================ */}
            {mod.warnings && mod.warnings.length > 0 && (
                <section className="detail-section">
                    <SectionHeader icon={AlertTriangle} title="Warnings" variant="warning" />
                    <div className="detail-warnings">
                        {mod.warnings.map((warning, idx) => (
                            <div key={idx} className="detail-warning">
                                <AlertTriangle size={14} />
                                <span>{warning}</span>
                            </div>
                        ))}
                    </div>
                </section>
            )}

            {/* ================================
                8. DOWNLOAD ACTIONS
            ================================ */}
            {latestVersion && (
                <section className="detail-section detail-section--actions">
                    <div className="detail-download-box">
                        <div className="detail-download-info">
                            <span className="detail-download-label">Latest Release</span>
                            <div className="detail-download-version">
                                <code>v{latestVersion.version}</code>
                                <span className="detail-download-size">{latestVersion.fileSize}</span>
                            </div>
                        </div>
                        <div className="detail-download-actions">
                            <Link href={`/d/${latestVersion.downloadSlug}`} className="detail-btn detail-btn--primary">
                                <Download size={18} />
                                <span>Download {mod.type === "mod" ? "APK" : "Script"}</span>
                            </Link>
                            <button
                                type="button"
                                onClick={handleCopyLink}
                                className="detail-btn detail-btn--secondary"
                            >
                                {copied ? <Check size={16} /> : <Copy size={16} />}
                                <span>{copied ? "Link copied!" : "Copy link"}</span>
                            </button>
                        </div>
                    </div>

                    <VersionHistory versions={mod.versions} />
                </section>
            )}
        </article>
    );
}

// ============================================
// LOADING STATE
// ============================================

function LoadingState() {
    return (
        <main className="repo-page">
            <div className="repo-container">
                <div className="detail-loading">
                    <div className="loading-spinner" />
                    <span>Loading mod details...</span>
                </div>
            </div>
        </main>
    );
}

// ============================================
// ERROR STATE
// ============================================

function ErrorState({ message }: { message: string }) {
    return (
        <main className="repo-page">
            <div className="repo-container">
                <Link href="/mods" className="detail-back">
                    <ArrowLeft size={16} />
                    <span>Back to repository</span>
                </Link>
                <div className="detail-error">
                    <AlertCircle size={40} />
                    <h2>Mod Not Found</h2>
                    <p>{message}</p>
                    <Link href="/mods" className="detail-error-link">
                        <span>Browse all mods</span>
                        <ExternalLink size={14} />
                    </Link>
                </div>
            </div>
        </main>
    );
}

// ============================================
// PAGE COMPONENT
// ============================================

export default function ModDetailPage({ params }: { params: Promise<{ slug: string }> }) {
    const { slug } = use(params);
    const { mod, loading, error } = useMod(slug);

    if (loading) {
        return <LoadingState />;
    }

    if (error || !mod) {
        return <ErrorState message={error || "The requested mod could not be found."} />;
    }

    return (
        <main className="repo-page">
            <div className="repo-container">
                <ModDetailView mod={mod} />
            </div>
        </main>
    );
}
