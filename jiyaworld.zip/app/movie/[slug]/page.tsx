"use client";

import { useState, useRef, useCallback } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import styles from "./detail.module.css";

interface Episode {
    number: number;
    title: string;
}

interface MovieInfo {
    slug: string;
    title: string;
    thumbnail: string;
    rating: number | null;
    year: string;
    type: "movie" | "series";
    genres: string[];
    synopsis: string;
    episodes: Episode[];
}

type ViewState = "detail" | "loading" | "playing" | "error";

function PlayIcon() {
    return (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M8 5v14l11-7z" />
        </svg>
    );
}

function BackIcon() {
    return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M19 12H5M12 19l-7-7 7-7" />
        </svg>
    );
}

function CloseIcon() {
    return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M18 6L6 18M6 6l12 12" />
        </svg>
    );
}

function StarIcon() {
    return <span>★</span>;
}

function useMovieInfo(slug: string | undefined) {
    const [movie, setMovie] = useState<MovieInfo | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const fetchedRef = useRef(false);

    if (slug && !fetchedRef.current) {
        fetchedRef.current = true;
        fetch(`/api/movie-detail?slug=${encodeURIComponent(slug)}`)
            .then((res) => res.json())
            .then((data) => {
                if (data.success && data.data) {
                    setMovie({
                        slug: data.data.slug,
                        title: data.data.title,
                        thumbnail: data.data.thumbnail,
                        rating: data.data.rating,
                        year: data.data.year,
                        type: data.data.type,
                        genres: data.data.genres || [],
                        synopsis: data.data.synopsis || "",
                        episodes: (data.data.episodes || []).map((ep: { number: number; title?: string }) => ({
                            number: ep.number,
                            title: ep.title || `Episode ${ep.number}`,
                        })),
                    });
                } else {
                    setError(data.error || "Not found");
                }
                setLoading(false);
            })
            .catch(() => {
                setError("Failed to load");
                setLoading(false);
            });
    }

    return { movie, loading, error };
}

export default function MovieDetailPage() {
    const params = useParams();
    const slug = params?.slug as string;
    const videoRef = useRef<HTMLVideoElement>(null);

    const { movie, loading: infoLoading, error: infoError } = useMovieInfo(slug);

    const [viewState, setViewState] = useState<ViewState>("detail");
    const [streamUrl, setStreamUrl] = useState<string | null>(null);
    const [subtitleUrl, setSubtitleUrl] = useState<string | null>(null);
    const [streamError, setStreamError] = useState<string | null>(null);
    const [playingEpisode, setPlayingEpisode] = useState<number | null>(null);

    const handlePlayClick = useCallback(async (episodeNumber?: number) => {
        setViewState("loading");
        setStreamUrl(null);
        setSubtitleUrl(null);
        setStreamError(null);
        setPlayingEpisode(episodeNumber ?? null);

        try {
            let url = `/api/resolve-stream?slug=${encodeURIComponent(slug)}`;
            if (episodeNumber !== undefined) {
                url += `&episode=${episodeNumber}`;
            }

            const res = await fetch(url, { cache: "no-store" });
            const data = await res.json();

            if (data.success && data.video_url) {
                setStreamUrl(data.video_url);
                setSubtitleUrl(data.subtitle_url || null);
                setViewState("playing");
            } else {
                setStreamError(data.error || "Stream unavailable");
                setViewState("error");
            }
        } catch {
            setStreamError("Failed to load stream");
            setViewState("error");
        }
    }, [slug]);

    const handleClose = useCallback(() => {
        setViewState("detail");
        setStreamUrl(null);
        setSubtitleUrl(null);
        setStreamError(null);
        setPlayingEpisode(null);
    }, []);

    const handleVideoError = useCallback(() => {
        setStreamError("Playback failed");
        setViewState("error");
    }, []);

    if (infoLoading) {
        return (
            <div className={styles.page}>
                <div className={styles.centerState}>
                    <div className={styles.spinner} />
                    <p>Loading...</p>
                </div>
            </div>
        );
    }

    if (infoError || !movie) {
        return (
            <div className={styles.page}>
                <div className={styles.centerState}>
                    <h2>Not Found</h2>
                    <p>{infoError || "Content not available"}</p>
                    <Link href="/watch" className={styles.backBtn}>
                        <BackIcon /> Back
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className={styles.page}>
            {/* Player Overlay - only when loading/playing/error */}
            {viewState !== "detail" && (
                <div className={styles.playerOverlay}>
                    <div className={styles.playerBox}>
                        <button className={styles.closeBtn} onClick={handleClose}>
                            <CloseIcon />
                        </button>

                        <div className={styles.playerArea}>
                            {viewState === "loading" && (
                                <div className={styles.playerState}>
                                    <div className={styles.spinner} />
                                    <p>Loading stream...</p>
                                </div>
                            )}

                            {viewState === "error" && (
                                <div className={styles.playerState}>
                                    <div className={styles.errorBadge}>!</div>
                                    <h3>Stream Unavailable</h3>
                                    <p>{streamError}</p>
                                    <button className={styles.retryBtn} onClick={() => handlePlayClick(playingEpisode ?? undefined)}>
                                        Retry
                                    </button>
                                </div>
                            )}

                            {viewState === "playing" && streamUrl && (
                                <video
                                    ref={videoRef}
                                    className={styles.video}
                                    controls
                                    autoPlay
                                    playsInline
                                    poster={movie.thumbnail}
                                    onError={handleVideoError}
                                >
                                    <source src={streamUrl} type="video/mp4" />
                                    {subtitleUrl && (
                                        <track kind="subtitles" src={subtitleUrl} srcLang="en" label="English" default />
                                    )}
                                </video>
                            )}
                        </div>

                        <div className={styles.playerMeta}>
                            <span className={styles.nowPlaying}>Now Playing</span>
                            <span className={styles.playerTitle}>
                                {movie.title}{playingEpisode ? ` - Episode ${playingEpisode}` : ""}
                            </span>
                        </div>
                    </div>
                </div>
            )}

            {/* Backdrop */}
            <div className={styles.backdrop}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={movie.thumbnail} alt="" />
                <div className={styles.backdropFade} />
            </div>

            {/* Content */}
            <main className={styles.main}>
                <nav className={styles.nav}>
                    <Link href="/watch" className={styles.navLink}>
                        <BackIcon /> <span>Browse</span>
                    </Link>
                </nav>

                <section className={styles.header}>
                    <div className={styles.poster}>
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={movie.thumbnail} alt={movie.title} />
                    </div>

                    <div className={styles.details}>
                        <div className={styles.meta}>
                            <span className={styles.badge}>{movie.type}</span>
                            {movie.rating !== null && (
                                <span className={styles.rating}><StarIcon /> {movie.rating.toFixed(1)}</span>
                            )}
                            {movie.year && <span className={styles.year}>{movie.year}</span>}
                        </div>

                        <h1 className={styles.title}>{movie.title}</h1>

                        {movie.genres.length > 0 && (
                            <div className={styles.genres}>
                                {movie.genres.map((g, i) => (
                                    <span key={i} className={styles.genre}>{g}</span>
                                ))}
                            </div>
                        )}

                        {movie.synopsis && <p className={styles.synopsis}>{movie.synopsis}</p>}

                        {movie.type === "movie" && (
                            <div className={styles.playSection}>
                                <button className={styles.playBtn} onClick={() => handlePlayClick()}>
                                    <PlayIcon /> Play
                                </button>
                                <p className={styles.playHint}>Click to start streaming</p>
                            </div>
                        )}
                    </div>
                </section>

                {movie.type === "series" && movie.episodes.length > 0 && (
                    <section className={styles.episodes}>
                        <div className={styles.episodesHead}>
                            <h2 className={styles.sectionTitle}>Episodes</h2>
                            <select className={styles.seasonPicker}>
                                <option>Season 1</option>
                            </select>
                        </div>

                        <div className={styles.episodeList}>
                            {movie.episodes.map((ep) => (
                                <div
                                    key={ep.number}
                                    className={styles.episodeRow}
                                    onClick={() => handlePlayClick(ep.number)}
                                >
                                    <div className={styles.epThumb}>
                                        {/* eslint-disable-next-line @next/next/no-img-element */}
                                        <img src={movie.thumbnail} alt="" />
                                        <div className={styles.epOverlay}>
                                            <div className={styles.epPlayIcon}><PlayIcon /></div>
                                        </div>
                                    </div>
                                    <div className={styles.epInfo}>
                                        <span className={styles.epNum}>Episode {ep.number}</span>
                                        <span className={styles.epTitle}>{ep.title}</span>
                                        <span className={styles.epAction}>Click to play</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </section>
                )}
            </main>
        </div>
    );
}
