"use client";

import { useEffect, useState } from "react";
import { useParams, useSearchParams } from "next/navigation";
import Link from "next/link";
import styles from "./player.module.css";

interface Episode {
    number: number;
    title: string;
    player_url: string | null;
}

interface MovieData {
    title: string;
    thumbnail: string;
    type: "movie" | "series";
    player_url: string | null;
    episodes: Episode[];
}

interface DetailResponse {
    success: boolean;
    data?: MovieData;
}

function PlayIcon() {
    return (
        <svg viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
            <path d="M8 5v14l11-7z" />
        </svg>
    );
}

function ExternalIcon() {
    return (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3" />
        </svg>
    );
}

export default function WatchRedirectPage() {
    const params = useParams();
    const searchParams = useSearchParams();
    const slug = params?.slug as string;
    const episodeParam = searchParams.get("ep");

    const [movie, setMovie] = useState<MovieData | null>(null);
    const [playerUrl, setPlayerUrl] = useState<string | null>(null);
    const [title, setTitle] = useState<string>("");
    const [loading, setLoading] = useState(true);
    const [opened, setOpened] = useState(false);

    useEffect(() => {
        async function fetchAndOpen() {
            if (!slug) {
                setLoading(false);
                return;
            }

            try {
                const res = await fetch(`/api/movie-detail?slug=${encodeURIComponent(slug)}`);
                const data: DetailResponse = await res.json();

                if (!data.success || !data.data) {
                    setLoading(false);
                    return;
                }

                setMovie(data.data);

                let url: string | null = null;
                let displayTitle = data.data.title;

                if (data.data.type === "series" && episodeParam) {
                    const epNum = parseInt(episodeParam);
                    const episode = data.data.episodes.find((e) => e.number === epNum);
                    if (episode && episode.player_url) {
                        url = episode.player_url;
                        displayTitle = `${data.data.title} - Episode ${epNum}`;
                    }
                } else if (data.data.player_url) {
                    url = data.data.player_url;
                }

                setPlayerUrl(url);
                setTitle(displayTitle);
                setLoading(false);

                if (url) {
                    setTimeout(() => {
                        window.open(url!, "_blank", "noopener,noreferrer");
                        setOpened(true);
                    }, 1000);
                }
            } catch {
                setLoading(false);
            }
        }

        fetchAndOpen();
    }, [slug, episodeParam]);

    const handleManualOpen = () => {
        if (playerUrl) {
            window.open(playerUrl, "_blank", "noopener,noreferrer");
            setOpened(true);
        }
    };

    if (loading) {
        return (
            <div className={styles.container}>
                <div className={styles.card}>
                    <div className={styles.spinner} />
                    <h1 className={styles.title}>Loading...</h1>
                </div>
            </div>
        );
    }

    if (!movie || !playerUrl) {
        return (
            <div className={styles.container}>
                <div className={styles.card}>
                    <div className={styles.errorIcon}>!</div>
                    <h1 className={styles.title}>Not Available</h1>
                    <p className={styles.message}>This content is not available for streaming.</p>
                    <Link href={`/movie/${slug}`} className={styles.backLink}>
                        ← Back to Details
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className={styles.container}>
            <div className={styles.card}>
                <div className={styles.poster}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={movie.thumbnail} alt={title} />
                </div>

                {!opened ? (
                    <>
                        <div className={styles.spinner} />
                        <h1 className={styles.title}>Opening Player...</h1>
                        <p className={styles.subtitle}>{title}</p>
                        <p className={styles.message}>
                            The streaming player is opening in a new tab.
                        </p>
                    </>
                ) : (
                    <>
                        <h1 className={styles.title}>Player Opened</h1>
                        <p className={styles.subtitle}>{title}</p>
                        <p className={styles.message}>
                            The streaming player should now be open in a new tab.
                        </p>
                    </>
                )}

                <div className={styles.actions}>
                    <button className={styles.openButton} onClick={handleManualOpen}>
                        <PlayIcon />
                        <span>Open Player</span>
                        <ExternalIcon />
                    </button>
                </div>

                <p className={styles.hint}>
                    If the player didn&apos;t open,{" "}
                    <a
                        href={playerUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={styles.link}
                    >
                        click here
                    </a>
                </p>

                <Link href={`/movie/${slug}`} className={styles.backLink}>
                    ← Back to Movie Details
                </Link>
            </div>
        </div>
    );
}
