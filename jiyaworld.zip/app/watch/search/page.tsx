"use client";

import { useState, FormEvent } from "react";
import Link from "next/link";
import styles from "../watch.module.css";

interface MovieResult {
    slug: string;
    title: string;
    thumbnail: string;
    rating: number | null;
    type: "movie" | "series";
}

interface SearchResponse {
    success: boolean;
    results: MovieResult[];
    error?: string;
}

function PlayIcon() {
    return (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M8 5v14l11-7z" />
        </svg>
    );
}

function StarIcon() {
    return <span style={{ color: "#fbbf24" }}>★</span>;
}

function MovieCard({ movie, idx }: { movie: MovieResult; idx: number }) {
    return (
        <Link href={`/movie/${movie.slug}`} className={styles.movieCard}>
            <div className={styles.cardPoster}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                    src={movie.thumbnail || "/placeholder-poster.jpg"}
                    alt={movie.title}
                    loading="lazy"
                    onError={(e) => {
                        (e.target as HTMLImageElement).style.background = "#1a1a24";
                    }}
                />
                <div className={styles.cardOverlay}>
                    <div className={styles.playIcon}>
                        <PlayIcon />
                    </div>
                </div>
            </div>
            <div className={styles.cardInfo}>
                <h3 className={styles.cardTitle}>{movie.title}</h3>
                <div className={styles.cardMeta}>
                    {movie.rating !== null && (
                        <span className={styles.cardRating}>
                            <StarIcon /> {movie.rating.toFixed(1)}
                        </span>
                    )}
                    <span className={styles.cardType}>{movie.type}</span>
                </div>
            </div>
        </Link>
    );
}

export default function SearchPage() {
    const [query, setQuery] = useState("");
    const [results, setResults] = useState<MovieResult[]>([]);
    const [loading, setLoading] = useState(false);
    const [hasSearched, setHasSearched] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSearch = async (e: FormEvent) => {
        e.preventDefault();
        if (!query.trim()) return;

        setLoading(true);
        setError(null);
        setHasSearched(true);
        setResults([]);

        try {
            const res = await fetch(`/api/external-search?q=${encodeURIComponent(query)}`);
            const data: SearchResponse = await res.json();

            if (data.success) {
                setResults(data.results);
            } else {
                setError(data.error || "Failed to fetch results");
            }
        } catch (err) {
            setError("An unexpected error occurred. Please try again.");
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className={styles.searchContainer}>
            <header className={styles.searchHeader}>
                <h1 className={styles.searchTitle}>Search Movies & Series</h1>
                <p className={styles.searchSubtitle}>Find your next favorite show to watch</p>

                <form onSubmit={handleSearch} className={styles.searchForm}>
                    <input
                        type="text"
                        className={styles.searchInput}
                        placeholder="Search for movies, series..."
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        autoFocus
                    />
                    <button type="submit" className={styles.searchBtn} disabled={loading}>
                        {loading ? "..." : "Search"}
                    </button>
                </form>
            </header>

            <main className={styles.searchResults}>
                {loading && (
                    <div className={styles.loader}>
                        <div className={styles.spinner} />
                    </div>
                )}

                {error && (
                    <div className={styles.emptyState}>
                        <p style={{ color: "#e50914" }}>{error}</p>
                    </div>
                )}

                {!loading && hasSearched && results.length === 0 && !error && (
                    <div className={styles.emptyState}>
                        <h3>No results found</h3>
                        <p>Try searching with different keywords.</p>
                    </div>
                )}

                {results.length > 0 && (
                    <>
                        <p className={styles.resultsCount}>
                            Found {results.length} result{results.length !== 1 ? "s" : ""} for &quot;{query}&quot;
                        </p>
                        <div className={styles.movieRow}>
                            {results.map((movie, idx) => (
                                <MovieCard key={`search-${movie.slug}-${idx}`} movie={movie} idx={idx} />
                            ))}
                        </div>
                    </>
                )}
            </main>
        </div>
    );
}
