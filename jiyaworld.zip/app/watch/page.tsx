"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import styles from "./watch.module.css";

interface MovieResult {
    slug: string;
    title: string;
    thumbnail: string;
    rating: number | null;
    type: "movie" | "series";
}

interface SearchResponse {
    success: boolean;
    results: MovieResult[];
}

const SAMPLE_QUERIES = ["action", "love", "night", "dark", "star", "dragon", "king", "fire"];

function PlayIcon() {
    return (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M8 5v14l11-7z" />
        </svg>
    );
}

function StarIcon() {
    return <span style={{ color: "#fbbf24" }}>★</span>;
}

function MovieCard({ movie, keyPrefix }: { movie: MovieResult; keyPrefix?: string }) {
    return (
        <Link href={`/movie/${movie.slug}`} className={styles.movieCard}>
            <div className={styles.cardPoster}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                    src={movie.thumbnail || "/placeholder-poster.jpg"}
                    alt={movie.title}
                    loading="lazy"
                    onError={(e) => {
                        (e.target as HTMLImageElement).style.background = "#1a1a24";
                    }}
                />
                <div className={styles.cardOverlay}>
                    <div className={styles.playIcon}>
                        <PlayIcon />
                    </div>
                </div>
            </div>
            <div className={styles.cardInfo}>
                <h3 className={styles.cardTitle}>{movie.title}</h3>
                <div className={styles.cardMeta}>
                    {movie.rating !== null && (
                        <span className={styles.cardRating}>
                            <StarIcon /> {movie.rating.toFixed(1)}
                        </span>
                    )}
                    <span className={styles.cardType}>{movie.type}</span>
                </div>
            </div>
        </Link>
    );
}

function deduplicateBySlug(movies: MovieResult[]): MovieResult[] {
    const seen = new Set<string>();
    return movies.filter((movie) => {
        if (seen.has(movie.slug)) return false;
        seen.add(movie.slug);
        return true;
    });
}

export default function WatchHomePage() {
    const [featured, setFeatured] = useState<MovieResult | null>(null);
    const [trending, setTrending] = useState<MovieResult[]>([]);
    const [recommended, setRecommended] = useState<MovieResult[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchMovies() {
            try {
                const query1 = SAMPLE_QUERIES[Math.floor(Math.random() * SAMPLE_QUERIES.length)];
                const query2 = SAMPLE_QUERIES[Math.floor(Math.random() * SAMPLE_QUERIES.length)];

                const [res1, res2] = await Promise.all([
                    fetch(`/api/external-search?q=${query1}`),
                    fetch(`/api/external-search?q=${query2}`),
                ]);

                const [data1, data2]: [SearchResponse, SearchResponse] = await Promise.all([
                    res1.json(),
                    res2.json(),
                ]);

                const allMovies = deduplicateBySlug([
                    ...(data1.success ? data1.results : []),
                    ...(data2.success ? data2.results : []),
                ]);

                const shuffled = [...allMovies].sort(() => Math.random() - 0.5);

                if (shuffled.length > 0) {
                    setFeatured(shuffled[0]);
                    setTrending(shuffled.slice(1, 7));
                    setRecommended(shuffled.slice(7, 14));
                }
            } catch (error) {
                console.error("Failed to fetch movies:", error);
            } finally {
                setLoading(false);
            }
        }

        fetchMovies();
    }, []);

    if (loading) {
        return (
            <div className={styles.pageContainer}>
                <div className={styles.loader}>
                    <div className={styles.spinner} />
                </div>
            </div>
        );
    }

    return (
        <div className={styles.pageContainer}>
            {/* Hero Section */}
            {featured && (
                <section className={styles.hero}>
                    <div className={styles.heroBg}>
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={featured.thumbnail} alt={featured.title} />
                    </div>
                    <div className={styles.heroOverlay} />
                    <div className={styles.heroContent}>
                        <div className={styles.heroMeta}>
                            <span className={styles.heroBadge}>{featured.type}</span>
                            {featured.rating && (
                                <span className={styles.heroRating}>
                                    <StarIcon /> {featured.rating.toFixed(1)}
                                </span>
                            )}
                        </div>
                        <h1 className={styles.heroTitle}>{featured.title}</h1>
                        <p className={styles.heroDescription}>
                            Experience the thrill of this acclaimed {featured.type}. Stream now in stunning quality.
                        </p>
                        <div className={styles.heroActions}>
                            <Link href={`/movie/${featured.slug}`} className={styles.btnWatch}>
                                <PlayIcon /> Watch Now
                            </Link>
                            <Link href={`/movie/${featured.slug}`} className={styles.btnInfo}>
                                More Info
                            </Link>
                        </div>
                    </div>
                </section>
            )}

            {/* Trending Section */}
            {trending.length > 0 && (
                <section className={styles.section}>
                    <div className={styles.sectionHeader}>
                        <h2 className={styles.sectionTitle}>Trending Now</h2>
                        <Link href="/watch/search" className={styles.viewAll}>
                            View All →
                        </Link>
                    </div>
                    <div className={styles.movieRow}>
                        {trending.map((movie, idx) => (
                            <MovieCard key={`trending-${movie.slug}-${idx}`} movie={movie} keyPrefix="trending" />
                        ))}
                    </div>
                </section>
            )}

            {/* Recommended Section */}
            {recommended.length > 0 && (
                <section className={styles.section}>
                    <div className={styles.sectionHeader}>
                        <h2 className={styles.sectionTitle}>Recommended For You</h2>
                    </div>
                    <div className={styles.movieRow}>
                        {recommended.map((movie, idx) => (
                            <MovieCard key={`recommended-${movie.slug}-${idx}`} movie={movie} keyPrefix="recommended" />
                        ))}
                    </div>
                </section>
            )}
        </div>
    );
}
