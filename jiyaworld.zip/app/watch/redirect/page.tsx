"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import styles from "./redirect.module.css";

export default function WatchRedirectPage() {
    const searchParams = useSearchParams();
    const url = searchParams.get("url");
    const title = searchParams.get("title") || "Content";
    const [countdown, setCountdown] = useState(3);
    const [error, setError] = useState(false);

    useEffect(() => {
        if (!url) {
            setError(true);
            return;
        }

        const timer = setInterval(() => {
            setCountdown((prev) => {
                if (prev <= 1) {
                    clearInterval(timer);
                    window.location.href = url;
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);

        return () => clearInterval(timer);
    }, [url]);

    if (error || !url) {
        return (
            <div className={styles.container}>
                <div className={styles.card}>
                    <div className={styles.iconError}>!</div>
                    <h1 className={styles.title}>Invalid Request</h1>
                    <p className={styles.text}>No streaming URL was provided.</p>
                    <Link href="/watch" className={styles.backBtn}>
                        ← Back to Home
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className={styles.container}>
            <div className={styles.card}>
                <div className={styles.spinner} />
                <h1 className={styles.title}>Redirecting to Player</h1>
                <p className={styles.subtitle}>{title}</p>
                <p className={styles.countdown}>
                    Opening in <span>{countdown}</span> seconds...
                </p>
                <p className={styles.hint}>
                    If nothing happens,{" "}
                    <a href={url} className={styles.link}>
                        click here
                    </a>
                </p>
                <Link href="/watch" className={styles.cancelBtn}>
                    Cancel
                </Link>
            </div>
        </div>
    );
}
