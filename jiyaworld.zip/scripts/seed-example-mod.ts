/* scripts/seed-example-mod.ts */

/**
 * Example Mod Seed Script
 * 
 * Run this script to create an example mod post in Firestore.
 * Usage: npx tsx scripts/seed-example-mod.ts
 * 
 * Make sure you have Firebase credentials set up in .env.local
 */

import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore, collection, doc, writeBatch, Timestamp } from "firebase/firestore";

// Firebase config (uses same env vars as the app)
const firebaseConfig = {
    apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
    authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
    projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
    storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
    messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
    appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

// Initialize Firebase
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);

// Example mod data
const exampleMod = {
    name: "Mobile Legends ESP Overlay",
    slug: "ml-esp-overlay",
    game: "Mobile Legends: Bang Bang",
    type: "script" as const,
    status: "stable" as const,
    published: true,
    description: `Lightweight ESP overlay for Mobile Legends that displays enemy positions and cooldown timers on the minimap.

Designed for educational use and game analysis. Works on both rooted and non-rooted devices via virtual environment injection.

This script hooks into the game's rendering layer to provide real-time information without modifying game files. Performance overhead is minimal (~3% CPU usage).`,
    features: [
        { text: "Real-time enemy position tracking on minimap", risk: "none" as const },
        { text: "Ultimate cooldown indicators for all heroes", risk: "none" as const },
        { text: "Low CPU/GPU overhead (~3% usage)", risk: "none" as const },
        { text: "Auto-hide when streaming apps detected", risk: "none" as const },
        { text: "Drone view toggle", risk: "medium" as const, riskNote: "may trigger detection if overused" },
        { text: "Custom overlay opacity settings", risk: "none" as const },
        { text: "Works in all game modes including Ranked", risk: "low" as const, riskNote: "use at your own risk" },
    ],
    requirements: [
        "Android 10 or higher",
        "Game Guardian or Virtual Space installed",
        "2GB+ RAM recommended",
        "MLBB version 1.8.x – 1.9.x",
    ],
    installationSteps: [
        "Install Virtual Space or Parallel Space on your device",
        "Clone MLBB into the virtual environment",
        "Import the script file (.lua) into Game Guardian",
        "Launch MLBB through Virtual Space",
        "Start Game Guardian and execute the script",
        "Toggle features via the floating menu",
    ],
    warnings: [
        "Using this in ranked matches may result in account suspension",
        "Do not share screenshots or recordings with overlay visible",
        "Detection risk increases with prolonged drone view usage",
    ],
    versions: [
        {
            version: "2.4.1",
            status: "stable" as const,
            fileSize: "1.2 MB",
            downloadSlug: "ml-esp-241",
            downloadUrl: "https://example.com/downloads/ml-esp-2.4.1.lua",
            changelog: [
                "Fixed compatibility with MLBB 1.9.x",
                "Improved minimap overlay accuracy",
                "Reduced memory usage by 15%",
            ],
            isLatest: true,
        },
        {
            version: "2.4.0",
            status: "stable" as const,
            fileSize: "1.1 MB",
            downloadSlug: "ml-esp-240",
            downloadUrl: "https://example.com/downloads/ml-esp-2.4.0.lua",
            changelog: [
                "Added drone view toggle feature",
                "New auto-hide for streaming apps",
                "Performance optimizations",
            ],
            isLatest: false,
        },
    ],
};

async function seedExampleMod() {
    console.log("🚀 Seeding example mod...\n");

    const batch = writeBatch(db);
    const now = Timestamp.now();

    // Create mod document
    const modRef = doc(collection(db, "mods"));
    const modData = {
        ...exampleMod,
        createdAt: now,
        updatedAt: now,
        versions: exampleMod.versions.map((v, idx) => ({
            ...v,
            createdAt: new Date(Date.now() - idx * 7 * 24 * 60 * 60 * 1000).toISOString(), // Each version 1 week apart
        })),
    };

    batch.set(modRef, modData);

    // Create shortlinks for each version
    for (const version of exampleMod.versions) {
        const shortLinkRef = doc(db, "shortlinks", version.downloadSlug);
        batch.set(shortLinkRef, {
            url: version.downloadUrl,
            name: exampleMod.name,
            size: version.fileSize,
            game: exampleMod.game,
            version: version.version,
            status: version.status,
            type: exampleMod.type,
            fileType: ".lua",
            modId: modRef.id,
            createdAt: now,
        });
    }

    await batch.commit();

    console.log("✅ Example mod created successfully!");
    console.log(`   ID: ${modRef.id}`);
    console.log(`   Slug: ${exampleMod.slug}`);
    console.log(`   URL: /mods/${exampleMod.slug}`);
    console.log("\n📝 You can now view the mod at http://localhost:3000/mods/ml-esp-overlay");
}

seedExampleMod()
    .then(() => process.exit(0))
    .catch((err) => {
        console.error("❌ Error seeding mod:", err);
        process.exit(1);
    });
